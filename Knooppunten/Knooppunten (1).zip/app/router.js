import * as index from './pages/index';
import * as detail from './pages/detail';
import * as snelheid from './pages/snelheid';
//import * as replace from './pages/replace';

export default {
  index,
  detail,
  snelheid,
//  replace,
};
